# ----------------------------------------------------------------------------------------
# PROGRAMA: <<Juego de imagenes y video, proyecto final>>
# ----------------------------------------------------------------------------------------
# Descripción: <<Por medio de imagenes y videos se crean varios juegos donde el usuario debe cumplir los objetivos y subir de nivel>>
# Las siguientes son las indicaciones generales.
# ----------------------------------------------------------------------------------------
# Autores:
''' 
# Miguel David Benavides Galindo            md_benavidesg@javeriana.edu.co
# Christian Fernando Rodriguez Rodriguez    rodriguezchristianf@javeriana.edu.co
'''
# Version: 4.0
# [16.11.2021]
# ----------------------------------------------------------------------------------------
# IMPORTAR MODULOS
import os
import cv2 # opencv version 3.4.2
import numpy as np # numpy version 1.16.3
import random
import mediapipe as mp

### Definir ruta donde estan las carpetas de los juegos con las imagenes
ruta = "C:/Users/User/Desktop/Proyecto_imagenes_videos/Base_Proyecto"

# ----------------------------------------------------------------------------------------
# VARIABLES GLOBALES Y PRE-CONDICIONES
# ----------------------------------------------------------------------------------------

# invoca funcion mostrarMenu() para que el usuario seleccione un numero entre 0 y 4.
# Cada juego se ejecutará de acuerdo a la opción del menú

# ----------------------------------------------------------------------------------------
# POSTCONDICIONES
# ----------------------------------------------------------------------------------------

# 1. Imprime en pantalla el menu con las opciones, 
# retorno de la funcion mostrarMenu.

# Si selecciona numero 0: Termina el programa. 
# Si selecciona numero 1: Ingresa al juego # 1.
# Si selecciona numero 2: Ingresa al juego # 2.
# Si selecciona numero 3: Ingresa al juego # 3.
# Si selecciona numero 4: Ingresa al juego # 4.

# ----------------------------------------------------------------------------------------
# FUNCIONES
# ----------------------------------------------------------------------------------------
################################ FUNCION CAMBIAR ORDEN LISTA ################################
def mezclar_lista(lista_original):
    lista = lista_original[:]
    longitud_lista = len(lista)
    for i in range(longitud_lista):
        indice_aleatorio = random.randint(0, longitud_lista - 1)
        temporal = lista[i]
        lista[i] = lista[indice_aleatorio]
        lista[indice_aleatorio] = temporal
    return lista

################################ FUNCION IMAG BASES ################################
def Base_imagenes(ruta):
    Contenido = os.listdir(ruta)
    nombres = []
    for i in Contenido:
        nom = ruta+ "/" + str(i)
        nombres.append(nom)
    return nombres

################################ FUNCION RESPUESTA ################################
def Respuesta(original):  
    points = []
    def click(event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            points.append((x, y))
    
    image_draw = np.copy(original)
    
    points1 = []
    cv2.namedWindow("Seleccione su respuesta")
    cv2.setMouseCallback("Seleccione su respuesta", click)
    
    point_counter = 0
    print("Presione x, al terminar")
    while True:
        cv2.imshow("Seleccione su respuesta", image_draw)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("x"):
            points1 = points.copy()
            points = []
            break
        if len(points) > point_counter:
            point_counter = len(points)
            cv2.circle(image_draw, (points[-1][0], points[-1][1]), 8, [255, 0, 0], -1)
    del points, key, point_counter, image_draw
    cv2. destroyAllWindows()
    return points1

################################ JUEGO 1 ################################
def Juego_cambiar_cosas(original,nivel):
    # Convertimos a escala de grises
    image_draw = np.copy(original)
    gris = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
    
    ret, th = cv2.threshold(gris, 200, 255, cv2.THRESH_BINARY_INV)
    (contornos,_) = cv2.findContours(th.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    X = []
    Y = []
    W = []
    H = []
    Imagenes_insumo = []
    
    Sub_imag = 0
    for i in range(len(contornos)):  
        cnt = contornos[i]
        perimetro = cv2.arcLength(cnt, True)    
        x,y,w,h = cv2.boundingRect(cnt)  
        
        if perimetro > 300:
            X.append(x)
            Y.append(y)
            W.append(w)
            H.append(h)  
            
            imageOut = image_draw[y:y+h,x:x+w]
            Sub_imag = Sub_imag + 1
            Imagenes_insumo.append(imageOut)
    
    if Sub_imag == 1:
        X = []
        Y = []
        W = []
        H = []
        Imagenes_insumo = []
        # Aplicar suavizado Gaussiano
        gauss = cv2.GaussianBlur(gris, (5,5), 0)
        # Detectamos los bordes con Canny
        canny = cv2.Canny(gauss, 50, 150)
        #Buscamos los contornos
        (contornos,_) = cv2.findContours(canny.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
        for i in range(len(contornos)):  
            cnt = contornos[i]
           
            perimetro = cv2.arcLength(cnt, True)    
            x,y,w,h = cv2.boundingRect(cnt)
            
            if perimetro > 300:
                X.append(x)
                Y.append(y)
                W.append(w)
                H.append(h) 
                
                imageOut = image_draw[y:y+h,x:x+w]
                Imagenes_insumo.append(imageOut)
                
    X_Fi = []
    Y_Fi = []
    W_Fi = []
    H_Fi = []   
   
    for k in range(nivel):
        i = random.randint(0, len(Imagenes_insumo))
        j = random.randint(0, len(Imagenes_insumo))
        try:
            Imagenes_ins = cv2.resize(Imagenes_insumo[j], (W[i],H[i]))
            image_draw[Y[i]:Y[i]+H[i],X[i]:X[i]+W[i]] = Imagenes_ins
            
            X_Fi.append(X[i])
            Y_Fi.append(Y[i])
            W_Fi.append(W[i])
            H_Fi.append(H[i]) 

        except:
            None  
    return image_draw, X_Fi, W_Fi, Y_Fi, H_Fi

################################ JUEGO 2 ################################
# Reconocer cosas en una imagen a partir del color
def Juego_seleccionar_color(original):
    src_img = np.copy(original)
    src_img_gray = cv2.cvtColor(src_img, cv2.COLOR_BGR2GRAY)
    # Change colorspace from BGR to HSV
    src_img_hsv = cv2.cvtColor(src_img, cv2.COLOR_BGR2HSV)
    
    # Define limits of yellow HSV values
    yellow_lower = np.array([10, 90, 90])
    yellow_upper = np.array([55, 255, 255])
    
    green_lower = np.array([30,90,90])
    green_upper = np.array([90,255,255])
    
    red_lower1 = np.array([0,140,40])
    red_upper1 = np.array([15,255,255])
    red_lower2 = np.array([165,140,40])
    red_upper2 = np.array([190,255,255])
    
    blue_lower = np.array([90, 70, 160])
    blue_upper = np.array([136, 255, 255])
    
    pink_lower = np.array([150, 70, 160])
    pink_upper = np.array([180, 255, 255])
    
    orange_lower = np.array([0,140,170])
    orange_upper = np.array([26,255,255])
    
    mask_red1 = cv2.inRange(src_img_hsv, red_lower1, red_upper1)
    mask_red2 = cv2.inRange(src_img_hsv, red_lower2, red_upper2)
    
    # Filter the image and get the mask
    mask_yellow = cv2.inRange(src_img_hsv, yellow_lower, yellow_upper)
    mask_red = mask_red1 + mask_red2
    mask_green = cv2.inRange(src_img_hsv, green_lower, green_upper)
    mask_blue = cv2.inRange(src_img_hsv, blue_lower, blue_upper)
    mask_pink = cv2.inRange(src_img_hsv, pink_lower, pink_upper)
    mask_orange = cv2.inRange(src_img_hsv, orange_lower, orange_upper)
    
    colores = [mask_yellow,mask_red,mask_green,mask_blue,mask_pink,mask_orange]

    imagenes_final = []
    
    for i in range(len(colores)):
        src_imag_mask = src_img_gray * colores[i]
        
        masked = cv2.bitwise_and(src_img, src_img, mask=src_imag_mask)
        # Taking a matrix of size 3 as the kernel
        kernel = np.ones((3,3), np.uint8)
     
        img_erosion = cv2.erode(masked, kernel, iterations=1)
        img_dilation = cv2.dilate(img_erosion, kernel, iterations=1)
        
        imagenes_final.append(img_dilation)
    
    return imagenes_final

################################ JUEGO 3 ################################
# Muestra color por sobel
def gradient_map(gray):
    # Image derivatives
    scale = 1
    delta = 0
    depth = cv2.CV_16S  # to avoid overflow
    grad_x = cv2.Sobel(gray, depth, 1, 0, ksize=3, scale=scale, delta=delta)
    grad_y = cv2.Sobel(gray, depth, 0, 1, ksize=3, scale=scale, delta=delta)
    grad_x = np.float32(grad_x)
    grad_x = grad_x * (1 / 512)
    grad_y = np.float32(grad_y)
    grad_y = grad_y * (1 / 512)
    # Gradient and smoothing
    grad_x2 = cv2.multiply(grad_x, grad_x)
    grad_y2 = cv2.multiply(grad_y, grad_y)
    # Magnitude of the gradient
    Mag = np.sqrt(grad_x2 + grad_y2)
    # Orientation of the gradient
    theta = np.arctan(cv2.divide(grad_y, grad_x + np.finfo(float).eps))
    return theta, Mag

def Juego_sobel_color(original):
    image = np.copy(original)
    
    image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 1) high-pass kernels
    kernel = cv2.getDerivKernels(1, 0, 3)
    kernel = np.outer(kernel[1], kernel[0])
    # 2) convolution
    image_convolved = cv2.filter2D(image_gray, -1, kernel)
       
    image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  

    [theta_data, M] = gradient_map(image_gray)    
    theta_data += np.pi / 2
    theta_data /= np.pi
    theta_uint8 = theta_data * 255
    theta_uint8 = np.uint8(theta_uint8)
    theta_uint8 = cv2.applyColorMap(theta_uint8, cv2.COLORMAP_JET)
    theta_view = np.zeros(theta_uint8.shape)
    theta_view = np.uint8(theta_view)
    theta_view[M > 0.3] = theta_uint8[M > 0.3]
    return theta_view, image_convolved

# ----------------------------------------------------------------------------------------
# PARAMETROS
# ----------------------------------------------------------------------------------------
# listar aqui los parámetros

def mostrarMenu():
    op = 6
    while op < 0 or op > 5:
        print("*************************************************")
        print("**********MENU - Juegos Mentales*****************")
        print("*************************************************")
        print("1......................¿Cuales figuras cambiaron?")
        print("2.....................Memoria episodica por color")
        print("3......................................¿Quien es?")
        print("4.............................¿En que país estas?")
        print("*************************************************")
        op = int(input("Ingrese la opción deseada (1-4) o 0 para terminar: __"))
    return op

opc = 1
contador_1 = 0
contador_2 = 0
contador_3 = 0
contador_4 = 0

nivel = 1

ruta_juego_1 = ruta + "/Juego_1"
ruta_juego_2 = ruta + "/Juego_2"
ruta_juego_3 = ruta + "/Juego_3"
ruta_juego_4 = ruta + "/Juego_4"

ruta_juego_1_ima = Base_imagenes(ruta_juego_1)
ruta_juego_2_ima = Base_imagenes(ruta_juego_2)
ruta_juego_3_ima = Base_imagenes(ruta_juego_3)
ruta_juego_4_ima = Base_imagenes(ruta_juego_4)

ruta_juego_1_ima = mezclar_lista(ruta_juego_1_ima)
ruta_juego_2_ima = mezclar_lista(ruta_juego_2_ima)
ruta_juego_3_ima = mezclar_lista(ruta_juego_3_ima)
ruta_juego_4_ima = mezclar_lista(ruta_juego_4_ima)

while opc != 0:
    opc = mostrarMenu()
    
    if opc == 1:
        
        original = cv2.imread(ruta_juego_1_ima[contador_1])
        original = cv2.resize(original, (520,520))
        contador_1 = contador_1 + 1 
        if contador_1 == len(ruta_juego_1_ima):
            contador_1 = 0
            
        ##### Combinar primera forma
        cv2.imshow("Juego 1: Cuales figuras cambiaron?", original)
        cv2.waitKey(2000)
    
        resultado, X_Fi, W_Fi, Y_Fi, H_Fi = Juego_cambiar_cosas(original,nivel)
        
        print("¿Cuales figuras cambiaron?")
        puntos_respuesta = Respuesta(resultado)
        cv2. destroyAllWindows()
        
        puntos = 0
        
        for k in range(len(puntos_respuesta)):
            inicial = puntos
            for l in range(len(X_Fi)):
                if Y_Fi[l] < list(puntos_respuesta[k])[1] < Y_Fi[l] + H_Fi[l] and X_Fi[l] < list(puntos_respuesta[k])[0] < X_Fi[l] + W_Fi[l]:
                    puntos = puntos +1
                else:
                    None
            if  inicial == puntos:
                puntos = puntos - 0.5
            else:
                None
        
        print("Tienes",puntos,"/",len(X_Fi), " respuestas correctas")
        try: 
            if puntos/(len(X_Fi)) > 0.65:
                nivel = nivel + 1
                print("Has logrado subir al nivel", nivel)
            else:
                nivel = nivel
                print("No logras subir de nivel, se mantiene en", nivel)
        except:
            nivel = nivel
            print("No logras subir de nivel, se mantiene en", nivel)

    if opc == 2:
        
        original = cv2.imread(ruta_juego_2_ima[contador_2])
        original = cv2.resize(original, (520,520))
        contador_2 = contador_2 + 1 
        if contador_2 == len(ruta_juego_2_ima):
            contador_2 = 0
    
        resultado = Juego_seleccionar_color(original)
        cv2.imshow("Juego 2: Colores Amarillos de la Figura", resultado[0])
        cv2.waitKey(2500)

        cv2.imshow("Juego 2: Colores Rojos de la Figura", resultado[1])
        cv2.waitKey(2500)
        
        cv2.imshow("Juego 2: Colores Verdes de la Figura", resultado[2])
        cv2.waitKey(2500)
        
        cv2.imshow("Juego 2: Colores Azules de la Figura", resultado[3])
        cv2.waitKey(2500)

        cv2.imshow("Juego 2: Colores Rosados de la Figura", resultado[4])
        cv2.waitKey(2500)
        
        cv2.imshow("Juego 2: Colores Naranjas de la Figura", resultado[5])
        cv2.waitKey(2500)
        
        cv2.imshow("Juego 2: Imagen completa", original)
        cv2.waitKey(5000)
        
        cv2. destroyAllWindows()

    if opc == 3:  
        
        original = cv2.imread(ruta_juego_3_ima[contador_3])
        original = cv2.resize(original, (520,520))
            
        resultado = Juego_sobel_color(original)
        
        if nivel >= 5:
            imagen_juego_3 = resultado[0]
        else:
            imagen_juego_3 = resultado[1]
            
        if nivel > 10:
            num_nombres = 10
        else:
            num_nombres = nivel     
            
        nombres_3_pre = []
        for p in ruta_juego_3_ima:
            head, sep, tail = p.partition('Juego_3/')
            nombres_3_pre.append(tail)
             
        nombres_3 = []
        for p in nombres_3_pre:
            head, sep, tail = p.partition('.')
            nombres_3.append(head)
        
        respuesta_juego_3 = nombres_3[contador_3]
        
        nombres_3.insert(0, nombres_3[contador_3])
        
        nombres_3_def = list(dict.fromkeys(nombres_3))
        
        nombres_3_def = nombres_3_def[0:num_nombres]

        nombres_3_def = mezclar_lista(nombres_3_def)
        
        for i in range(num_nombres):
            tipoLetra = cv2.FONT_HERSHEY_COMPLEX_SMALL
            texto = nombres_3_def[i]
            tamañoLetra = 0.7
            colorLetra = (255, 0, 255)
            grosorLetra = 1
            ubicacion = (20,30+50*i)
            cv2.putText(imagen_juego_3, texto, ubicacion, tipoLetra, tamañoLetra, colorLetra, grosorLetra, cv2.LINE_AA)
                    
        print("¿Quien es?")
        puntos_respuesta = Respuesta(imagen_juego_3)
        cv2. destroyAllWindows()
        
        X_Fi = [0]*num_nombres
        W_Fi = [150]*num_nombres
        Y_Fi = [0,50,100,150,200,250,300,350,400,450]
        H_Fi = [50,100,150,200,250,300,350,400,450,500]
        
        Y_Fi = Y_Fi[0:num_nombres]
        H_Fi = H_Fi[0:num_nombres]

        puntos = 0
        
        for k in range(len(puntos_respuesta)):
            inicial = puntos
            for l in range(len(X_Fi)):
                if X_Fi[l] < list(puntos_respuesta[k])[0] < X_Fi[l] + W_Fi[l] and Y_Fi[l] < list(puntos_respuesta[k])[1] < Y_Fi[l] + H_Fi[l]:
                    if nombres_3_def[l] == respuesta_juego_3:
                        puntos = puntos + 1
                else:
                    None
                    
            if  inicial == puntos:
                puntos = puntos - 0.5
            else:
                None

        if puntos >= 1:
            nivel = nivel + 1
            print("Tu respuesta es correcta. Has logrado subir al nivel", nivel)
        else:
            nivel = nivel
            print("Tu respuesta es incorrecta. No logras subir de nivel, se mantiene en", nivel)
            
        cv2.imshow("Juego 3: Quien es?", original)
        cv2.waitKey(3000)
        
        cv2. destroyAllWindows()
        
        contador_3 = contador_3 + 1 
        if contador_3 == len(ruta_juego_3_ima):
            contador_3 = 0
            
    if opc == 4:
        
        if nivel > 10:
            num_nombres = 10
        else:
            num_nombres = nivel 
        
        nombres_4_pre = []
        for p in ruta_juego_4_ima:
            head, sep, tail = p.partition('Juego_4/')
            nombres_4_pre.append(tail)
               
        nombres_4 = []
        for p in nombres_4_pre:
            head, sep, tail = p.partition('.')
            nombres_4.append(head)
          
        respuesta_juego_4 = nombres_4[contador_4]
          
        nombres_4.insert(0, nombres_4[contador_4])
          
        nombres_4_def = list(dict.fromkeys(nombres_4))
          
        nombres_4_def = nombres_4_def[0:num_nombres]
  
        nombres_4_def = mezclar_lista(nombres_4_def)
        
        mp_selfie_segmentation = mp.solutions.selfie_segmentation
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        with mp_selfie_segmentation.SelfieSegmentation(
             model_selection=0) as selfie_segmentation:
             while True:
                  # Lectura del video de entrada
                  ret, frame = cap.read()
                  if ret == False:
                       break
                   
                  frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                  results = selfie_segmentation.process(frame_rgb)
                  
                  _, th = cv2.threshold(results.segmentation_mask, 0.75, 255, cv2.THRESH_BINARY)
                  th = th.astype(np.uint8)
                  th = cv2.medianBlur(th, 13)
                  th_inv = cv2.bitwise_not(th)
                  
                  bg_image = cv2.imread(ruta_juego_4_ima[contador_4])
                  bg_image = cv2.resize(bg_image, (640,480))
                  
                  bg = cv2.bitwise_and(bg_image, bg_image, mask=th_inv)
                  
                  fg = cv2.bitwise_and(frame, frame, mask=th)
                  
                  output_image = cv2.add(bg, fg)
                                       
                  for i in range(num_nombres):
                      tipoLetra = cv2.FONT_HERSHEY_COMPLEX_SMALL
                      texto = nombres_4_def[i]
                      tamañoLetra = 0.7
                      colorLetra = (255, 0, 255)
                      grosorLetra = 1
                      ubicacion = (20,30+50*i)
                      cv2.putText(output_image, texto, ubicacion, tipoLetra, tamañoLetra, colorLetra, grosorLetra, cv2.LINE_AA)

                  cv2.imshow("Juego 4: Donde estas?", output_image) 
    
                  key = cv2.waitKey(1) & 0xFF
                  if key == ord("x"):
                       break
        cap.release()
        print("¿Donde estas?")           
        puntos_respuesta = Respuesta(output_image)           
        cv2.destroyAllWindows()
 
        X_Fi = [0]*num_nombres
        W_Fi = [150]*num_nombres
        Y_Fi = [0,50,100,150,200,250,300,350,400,450]
        H_Fi = [50,100,150,200,250,300,350,400,450,500]
        
        Y_Fi = Y_Fi[0:num_nombres]
        H_Fi = H_Fi[0:num_nombres]

        puntos = 0
        
        for k in range(len(puntos_respuesta)):
            inicial = puntos
            for l in range(len(X_Fi)):
                if X_Fi[l] < list(puntos_respuesta[k])[0] < X_Fi[l] + W_Fi[l] and Y_Fi[l] < list(puntos_respuesta[k])[1] < Y_Fi[l] + H_Fi[l]:
                    if nombres_4_def[l] == respuesta_juego_4:
                        puntos = puntos + 1
                else:
                    None
                    
            if  inicial == puntos:
                puntos = puntos - 0.5
            else:
                None

        if puntos >= 1:
            nivel = nivel + 1
            print("Tu respuesta es correcta. Has logrado subir al nivel", nivel)
        else:
            nivel = nivel
            print("Tu respuesta es incorrecta. No logras subir de nivel, se mantiene en", nivel)
        
        contador_4 = contador_4 + 1 
        if contador_4 == len(ruta_juego_4_ima):
            contador_4 = 0

    elif opc == 0:
        print("Usted termino el juego satisfactoriamente")

# ----------------------------------------------------------------------------------------
# end.
# ----------------------------------------------------------------------------------------